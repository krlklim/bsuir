//---------------------------------------------------------------------------

#ifndef MainWindowH
#define MainWindowH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TListBox *ListBox;
	TButton *ButtonRandom;
	TListBox *ListBoxFirst;
	TListBox *ListBoxSecond;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TEdit *EditMin;
	TEdit *EditMax;
	TLabel *Label6;
	TLabel *Label7;
	void __fastcall ButtonRandomClick(TObject *Sender);
private:	// User declarations
public:
	void ShowOnListBox();
	void InTwoCircle(Queue &InputQueue);
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
